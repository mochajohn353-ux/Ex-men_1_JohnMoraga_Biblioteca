namespace BibliotecaApp;

// ============================================================
// Clase Libro: guarda los datos de un libro de la biblioteca
// ============================================================
public class Libro
{
    public string Codigo { get; set; }
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public string Categoria { get; set; }
    public int Anio { get; set; }
    public bool Disponible { get; set; }      // true = está en la biblioteca, false = está prestado
}

// ============================================================
// Clase Prestamo: guarda un préstamo que todavía está activo
// ============================================================
public class Prestamo
{
    public int Id { get; set; }               // número único del préstamo
    public DateTime Fecha { get; set; }       // cuándo se prestó
    public string CodigoLibro { get; set; }
    public string TituloLibro { get; set; }
    public string Usuario { get; set; }       // quién se llevó el libro
}

// ============================================================
// Clase Nodo: una "cajita" de la lista enlazada.
// Guarda un préstamo y apunta al siguiente nodo.
// ============================================================
public class Nodo
{
    public Prestamo Dato;       // el préstamo que guarda este nodo
    public Nodo Siguiente;      // el nodo que viene después (null si es el último)

    public Nodo(Prestamo dato)
    {
        Dato = dato;
        Siguiente = null;
    }
}

// ============================================================
// Clase ListaPrestamos: LISTA ENLAZADA SIMPLE hecha por nosotros.
// Guarda los préstamos activos. Cuando devuelven el libro, se borra.
// ============================================================
public class ListaPrestamos
{
    private Nodo cabeza;    // primer nodo de la lista
    private Nodo cola;      // último nodo de la lista

    // Dice si la lista no tiene nada
    public bool EstaVacia()
    {
        return cabeza == null;
    }

    // INSERTAR: agrega un préstamo al final de la lista
    public void Insertar(Prestamo p)
    {
        Nodo nuevo = new Nodo(p);

        if (cabeza == null)
        {
            // Si la lista estaba vacía, el nuevo nodo es el primero y el último
            cabeza = nuevo;
            cola = nuevo;
        }
        else
        {
            // Si no, el último actual apunta al nuevo, y el nuevo pasa a ser el último
            cola.Siguiente = nuevo;
            cola = nuevo;
        }
    }

    // BUSCAR por código de libro: devuelve el préstamo o null si ese libro no está prestado
    public Prestamo BuscarPorCodigo(string codigo)
    {
        Nodo actual = cabeza;                   // empezamos en el primer nodo

        while (actual != null)                  // mientras no se acabe la lista
        {
            if (actual.Dato.CodigoLibro.ToLower() == codigo.ToLower())
            {
                return actual.Dato;             // lo encontramos
            }
            actual = actual.Siguiente;          // pasamos al siguiente nodo
        }

        return null;                            // llegamos al final y no estaba
    }

    // BUSCAR por usuario: devuelve todos los préstamos de esa persona
    public List<Prestamo> BuscarPorUsuario(string usuario)
    {
        List<Prestamo> resultado = new List<Prestamo>();
        Nodo actual = cabeza;

        while (actual != null)
        {
            if (actual.Dato.Usuario.ToLower() == usuario.ToLower())
            {
                resultado.Add(actual.Dato);
            }
            actual = actual.Siguiente;
        }

        return resultado;
    }

    // ELIMINAR: borra el préstamo de ese libro (así se procesa una devolución)
    public bool Eliminar(string codigo)
    {
        if (cabeza == null)
        {
            return false;       // no hay nada que borrar
        }

        // CASO 1: el que se quiere borrar es el primero
        if (cabeza.Dato.CodigoLibro.ToLower() == codigo.ToLower())
        {
            cabeza = cabeza.Siguiente;      // la cabeza pasa al segundo nodo
            if (cabeza == null)
            {
                cola = null;                // la lista quedó vacía
            }
            return true;
        }

        // CASO 2: está en el medio o al final
        Nodo anterior = cabeza;
        Nodo actual = cabeza.Siguiente;

        while (actual != null)
        {
            if (actual.Dato.CodigoLibro.ToLower() == codigo.ToLower())
            {
                anterior.Siguiente = actual.Siguiente;   // el anterior se salta al nodo borrado
                if (actual == cola)
                {
                    cola = anterior;                     // si era el último, ahora el último es el anterior
                }
                return true;
            }
            anterior = actual;
            actual = actual.Siguiente;
        }

        return false;       // no se encontró ese libro
    }

    // RECORRER: devuelve todos los préstamos en orden
    public List<Prestamo> Recorrer()
    {
        List<Prestamo> lista = new List<Prestamo>();
        Nodo actual = cabeza;

        while (actual != null)
        {
            lista.Add(actual.Dato);
            actual = actual.Siguiente;
        }

        return lista;
    }
}
