namespace BibliotecaApp;

public partial class FrmBiblioteca : Form
{
    // ================= LAS 3 ESTRUCTURAS DE DATOS =================

    // 1) VECTOR (arreglo): guarda cuántos préstamos se han hecho en cada categoría.
    //    La posición 0 es "Novela", la 1 es "Ciencia", y así sucesivamente.
    string[] categorias = { "Novela", "Ciencia", "Historia", "Infantil", "Otros" };
    int[] prestamosPorCategoria = new int[5];

    // 2) LIST (igual que un ArrayList): guarda el catálogo de libros.
    List<Libro> catalogo = new List<Libro>();

    // 3) LISTA ENLAZADA (la hicimos en Clases.cs): guarda los préstamos activos.
    ListaPrestamos prestamos = new ListaPrestamos();

    // Contador para que cada préstamo tenga un número distinto
    int contadorId = 1;

    // Lo que se está mostrando en las listas de la pantalla.
    // Sirven para saber cuál libro o préstamo eligió el usuario.
    List<Libro> librosEnPantalla = new List<Libro>();
    List<Prestamo> prestamosEnPantalla = new List<Prestamo>();

    public FrmBiblioteca()
    {
        InitializeComponent();
    }

    // Se ejecuta una vez, cuando se abre el formulario
    private void FrmBiblioteca_Load(object sender, EventArgs e)
    {
        // Poner el vector en cero
        for (int i = 0; i < prestamosPorCategoria.Length; i++)
        {
            prestamosPorCategoria[i] = 0;
        }

        // Llenar el combo con las categorías
        for (int i = 0; i < categorias.Length; i++)
        {
            cmbCategoria.Items.Add(categorias[i]);
        }
        cmbCategoria.SelectedIndex = 0;

        ActualizarTodo();
    }

    // ================= MÉTODOS DE AYUDA =================

    // Muestra una lista de libros en la lista de la pantalla
    void MostrarLibros(List<Libro> lista)
    {
        librosEnPantalla = lista;
        lstLibros.Items.Clear();

        foreach (Libro l in lista)
        {
            string estado = "Disponible";
            if (!l.Disponible)
            {
                estado = "Prestado";
            }

            lstLibros.Items.Add(l.Codigo + "  |  " + l.Titulo + "  |  " + l.Autor + "  |  "
                + l.Categoria + "  |  " + l.Anio + "  |  " + estado);
        }
    }

    // Muestra una lista de préstamos en la lista de la pantalla
    void MostrarPrestamos(List<Prestamo> lista)
    {
        prestamosEnPantalla = lista;
        lstPrestamos.Items.Clear();

        foreach (Prestamo p in lista)
        {
            lstPrestamos.Items.Add("#" + p.Id + "  |  " + p.Fecha.ToString("dd/MM/yyyy HH:mm")
                + "  |  " + p.CodigoLibro + "  |  " + p.TituloLibro + "  |  Usuario: " + p.Usuario);
        }
    }

    // Recorre el vector y muestra el total de cada categoría
    void MostrarResumen()
    {
        string texto = "Préstamos realizados por categoría:" + Environment.NewLine;
        for (int i = 0; i < categorias.Length; i++)
        {
            texto = texto + Environment.NewLine + categorias[i] + ": " + prestamosPorCategoria[i];
        }
        lblResumen.Text = texto;
    }

    // Vuelve a mostrar todo en pantalla
    void ActualizarTodo()
    {
        MostrarLibros(catalogo);
        MostrarPrestamos(prestamos.Recorrer());
        MostrarResumen();
    }

    // Borra lo escrito en los cuadros
    void LimpiarCampos()
    {
        txtCodigo.Clear();
        txtTitulo.Clear();
        txtAutor.Clear();
        txtAnio.Clear();
        txtUsuario.Clear();
        cmbCategoria.SelectedIndex = 0;
        txtCodigo.Focus();
    }

    // Busca un libro por su código. Devuelve null si no existe.
    Libro BuscarLibro(string codigo)
    {
        foreach (Libro l in catalogo)
        {
            if (l.Codigo.ToLower() == codigo.ToLower())
            {
                return l;
            }
        }
        return null;
    }

    // Crea un libro y lo guarda en el List (empieza disponible)
    void CrearLibro(string codigo, string titulo, string autor, string categoria, int anio)
    {
        Libro l = new Libro();
        l.Codigo = codigo;
        l.Titulo = titulo;
        l.Autor = autor;
        l.Categoria = categoria;
        l.Anio = anio;
        l.Disponible = true;

        catalogo.Add(l);
    }

    // Presta un libro: usa las 3 estructuras.
    // Devuelve "" si salió bien, o el mensaje de error si algo falló.
    string Prestar(Libro l, string usuario)
    {
        if (!l.Disponible)
        {
            return "Ese libro ya está prestado.";
        }

        // Marcar el libro como prestado (en el List)
        l.Disponible = false;

        // Sumar 1 en la posición de su categoría en el vector
        int posicion = Array.IndexOf(categorias, l.Categoria);
        prestamosPorCategoria[posicion]++;

        // Guardar el préstamo en la lista enlazada
        Prestamo p = new Prestamo();
        p.Id = contadorId;
        contadorId++;
        p.Fecha = DateTime.Now;
        p.CodigoLibro = l.Codigo;
        p.TituloLibro = l.Titulo;
        p.Usuario = usuario;
        prestamos.Insertar(p);

        return "";
    }

    // Procesa una devolución: borra el préstamo de la lista enlazada
    // y deja el libro disponible otra vez.
    string Devolver(Libro l)
    {
        if (l.Disponible)
        {
            return "Ese libro no está prestado.";
        }

        prestamos.Eliminar(l.Codigo);
        l.Disponible = true;
        return "";
    }

    // ================= BOTONES DE LIBROS =================

    private void btnRegistrar_Click(object sender, EventArgs e)
    {
        // Revisar que no estén vacíos
        if (txtCodigo.Text.Trim() == "" || txtTitulo.Text.Trim() == "" || txtAutor.Text.Trim() == "")
        {
            MessageBox.Show("Escriba el código, el título y el autor.");
            return;
        }

        // Revisar que el año sea un número válido
        int anio;
        if (!int.TryParse(txtAnio.Text, out anio) || anio < 1000 || anio > DateTime.Now.Year)
        {
            MessageBox.Show("El año debe ser un número entre 1000 y " + DateTime.Now.Year + ".");
            return;
        }

        // Revisar que el código no se repita
        if (BuscarLibro(txtCodigo.Text.Trim()) != null)
        {
            MessageBox.Show("Ya existe un libro con ese código.");
            return;
        }

        CrearLibro(txtCodigo.Text.Trim(), txtTitulo.Text.Trim(), txtAutor.Text.Trim(), cmbCategoria.Text, anio);
        LimpiarCampos();
        ActualizarTodo();
        MessageBox.Show("Libro registrado.");
    }

    private void btnModificar_Click(object sender, EventArgs e)
    {
        Libro l = BuscarLibro(txtCodigo.Text.Trim());
        if (l == null)
        {
            MessageBox.Show("Elija un libro de la lista para modificarlo.");
            return;
        }

        if (txtTitulo.Text.Trim() == "" || txtAutor.Text.Trim() == "")
        {
            MessageBox.Show("Escriba el título y el autor.");
            return;
        }

        int anio;
        if (!int.TryParse(txtAnio.Text, out anio) || anio < 1000 || anio > DateTime.Now.Year)
        {
            MessageBox.Show("El año debe ser un número entre 1000 y " + DateTime.Now.Year + ".");
            return;
        }

        l.Titulo = txtTitulo.Text.Trim();
        l.Autor = txtAutor.Text.Trim();
        l.Categoria = cmbCategoria.Text;
        l.Anio = anio;

        ActualizarTodo();
        MessageBox.Show("Libro modificado.");
    }

    private void btnEliminar_Click(object sender, EventArgs e)
    {
        if (catalogo.Count == 0)
        {
            MessageBox.Show("No hay libros para eliminar.");
            return;
        }

        Libro l = BuscarLibro(txtCodigo.Text.Trim());
        if (l == null)
        {
            MessageBox.Show("Elija un libro de la lista para eliminarlo.");
            return;
        }

        // No se puede borrar un libro que está prestado
        if (!l.Disponible)
        {
            MessageBox.Show("Ese libro está prestado. Primero hay que devolverlo.");
            return;
        }

        DialogResult respuesta = MessageBox.Show("¿Seguro que desea eliminar " + l.Titulo + "?", "Confirmar", MessageBoxButtons.YesNo);
        if (respuesta == DialogResult.No)
        {
            return;
        }

        catalogo.Remove(l);

        LimpiarCampos();
        ActualizarTodo();
    }

    // Borra los cuadros y vuelve a mostrar todo (quita búsquedas y filtros)
    private void btnLimpiar_Click(object sender, EventArgs e)
    {
        LimpiarCampos();
        txtBuscar.Clear();
        ActualizarTodo();
    }

    private void btnSalir_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    // Al elegir un libro de la lista, sus datos pasan a los cuadros de texto
    private void lstLibros_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lstLibros.SelectedIndex < 0)
        {
            return;     // no hay nada elegido
        }

        Libro l = librosEnPantalla[lstLibros.SelectedIndex];
        txtCodigo.Text = l.Codigo;
        txtTitulo.Text = l.Titulo;
        txtAutor.Text = l.Autor;
        cmbCategoria.Text = l.Categoria;
        txtAnio.Text = l.Anio.ToString();
    }

    // Al elegir un préstamo de la lista, su código y usuario pasan a los cuadros
    private void lstPrestamos_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lstPrestamos.SelectedIndex < 0)
        {
            return;
        }

        Prestamo p = prestamosEnPantalla[lstPrestamos.SelectedIndex];
        txtCodigo.Text = p.CodigoLibro;
        txtUsuario.Text = p.Usuario;
    }

    // ================= PRÉSTAMOS Y DEVOLUCIONES =================

    private void btnPrestar_Click(object sender, EventArgs e)
    {
        Libro l = BuscarLibro(txtCodigo.Text.Trim());
        if (l == null)
        {
            MessageBox.Show("Elija un libro de la lista primero.");
            return;
        }

        if (txtUsuario.Text.Trim() == "")
        {
            MessageBox.Show("Escriba el nombre del usuario que se lleva el libro.");
            return;
        }

        string error = Prestar(l, txtUsuario.Text.Trim());
        if (error != "")
        {
            MessageBox.Show(error);
            return;
        }

        txtUsuario.Clear();
        ActualizarTodo();
        MessageBox.Show("Préstamo registrado.");
    }

    private void btnDevolver_Click(object sender, EventArgs e)
    {
        if (prestamos.EstaVacia())
        {
            MessageBox.Show("No hay préstamos activos.");
            return;
        }

        Libro l = BuscarLibro(txtCodigo.Text.Trim());
        if (l == null)
        {
            MessageBox.Show("Elija un libro o un préstamo de la lista primero.");
            return;
        }

        string error = Devolver(l);
        if (error != "")
        {
            MessageBox.Show(error);
            return;
        }

        txtUsuario.Clear();
        ActualizarTodo();
        MessageBox.Show("Libro devuelto.");
    }

    // Muestra solo los préstamos del usuario escrito en el cuadro "Usuario".
    // Si el cuadro está vacío, muestra todos.
    private void btnPrestamosUsuario_Click(object sender, EventArgs e)
    {
        if (prestamos.EstaVacia())
        {
            MessageBox.Show("No hay préstamos activos.");
            return;
        }

        if (txtUsuario.Text.Trim() == "")
        {
            MostrarPrestamos(prestamos.Recorrer());
            return;
        }

        List<Prestamo> lista = prestamos.BuscarPorUsuario(txtUsuario.Text.Trim());
        MostrarPrestamos(lista);

        if (lista.Count == 0)
        {
            MessageBox.Show("Ese usuario no tiene préstamos activos.");
        }
    }

    // ================= BUSCAR Y ORDENAR =================

    private void btnBuscar_Click(object sender, EventArgs e)
    {
        if (catalogo.Count == 0)
        {
            MessageBox.Show("No hay libros registrados.");
            return;
        }

        string texto = txtBuscar.Text.Trim().ToLower();
        if (texto == "")
        {
            MessageBox.Show("Escriba un título, autor o código para buscar.");
            return;
        }

        // Guardar en una lista aparte los libros que coinciden
        List<Libro> encontrados = new List<Libro>();
        foreach (Libro l in catalogo)
        {
            if (l.Titulo.ToLower().Contains(texto) || l.Autor.ToLower().Contains(texto) || l.Codigo.ToLower().Contains(texto))
            {
                encontrados.Add(l);
            }
        }

        MostrarLibros(encontrados);

        if (encontrados.Count == 0)
        {
            MessageBox.Show("No se encontró ningún libro.");
        }
    }

    // Ordena el List por título (método de la burbuja)
    private void btnOrdenarTitulo_Click(object sender, EventArgs e)
    {
        if (catalogo.Count == 0)
        {
            MessageBox.Show("No hay libros para ordenar.");
            return;
        }

        for (int i = 0; i < catalogo.Count - 1; i++)
        {
            for (int j = 0; j < catalogo.Count - 1 - i; j++)
            {
                // Si el de la izquierda va después en el abecedario, se intercambian
                if (string.Compare(catalogo[j].Titulo, catalogo[j + 1].Titulo, true) > 0)
                {
                    Libro temporal = catalogo[j];
                    catalogo[j] = catalogo[j + 1];
                    catalogo[j + 1] = temporal;
                }
            }
        }

        MostrarLibros(catalogo);
    }

    // Ordena el List por año, del más viejo al más nuevo (método de la burbuja)
    private void btnOrdenarAnio_Click(object sender, EventArgs e)
    {
        if (catalogo.Count == 0)
        {
            MessageBox.Show("No hay libros para ordenar.");
            return;
        }

        for (int i = 0; i < catalogo.Count - 1; i++)
        {
            for (int j = 0; j < catalogo.Count - 1 - i; j++)
            {
                if (catalogo[j].Anio > catalogo[j + 1].Anio)
                {
                    Libro temporal = catalogo[j];
                    catalogo[j] = catalogo[j + 1];
                    catalogo[j + 1] = temporal;
                }
            }
        }

        MostrarLibros(catalogo);
    }

    // ================= DATOS DE EJEMPLO =================

    private void btnEjemplo_Click(object sender, EventArgs e)
    {
        if (catalogo.Count > 0)
        {
            MessageBox.Show("Ya hay datos cargados.");
            return;
        }

        CrearLibro("L001", "Cien años de soledad", "Gabriel García Márquez", "Novela", 1967);
        CrearLibro("L002", "El principito", "Antoine de Saint-Exupéry", "Infantil", 1943);
        CrearLibro("L003", "Breve historia del tiempo", "Stephen Hawking", "Ciencia", 1988);
        CrearLibro("L004", "Don Quijote de la Mancha", "Miguel de Cervantes", "Novela", 1605);
        CrearLibro("L005", "Sapiens", "Yuval Noah Harari", "Historia", 2011);
        CrearLibro("L006", "El origen de las especies", "Charles Darwin", "Ciencia", 1859);
        CrearLibro("L007", "Mamita Yunai", "Carlos Luis Fallas", "Novela", 1941);
        CrearLibro("L008", "Diario de Ana Frank", "Ana Frank", "Historia", 1947);

        // Unos préstamos para que la lista no quede vacía
        Prestar(BuscarLibro("L001"), "María Rojas");
        Prestar(BuscarLibro("L003"), "Carlos Vargas");
        Prestar(BuscarLibro("L005"), "María Rojas");

        ActualizarTodo();
    }
}
