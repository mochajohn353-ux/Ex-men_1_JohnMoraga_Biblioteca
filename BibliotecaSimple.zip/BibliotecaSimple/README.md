# Sistema de Biblioteca

- **Estudiante:** _(escriba aquí su nombre completo)_
- **Curso:** ISB-08 Organización de Archivos y Estructura de Datos, UISIL
- **Proyecto:** Opción 2, Biblioteca
- **Lenguaje:** C# con Windows Forms (.NET 8)

## Qué hace el programa

- Registrar, modificar y eliminar libros del catálogo.
- Buscar libros por título, autor o código.
- Ordenar el catálogo por título o por año.
- Prestar un libro a un usuario y procesar la devolución.
- Ver los préstamos activos, todos o solo los de un usuario.
- Contar cuántos préstamos se han hecho en cada categoría.
- Avisar con mensajes cuando los datos están mal o cuando no hay nada que mostrar.

## Cómo ejecutarlo

1. Instalar Visual Studio 2022 con la carga de trabajo "Desarrollo de escritorio de .NET" (o el SDK de .NET 8).
2. Abrir el archivo `BibliotecaApp.csproj`.
3. Presionar F5.

Para la demostración: presionar el botón **"Datos de ejemplo"**. Carga 8 libros y deja 3 préstamos activos.

## Estructuras de datos usadas

| Estructura | Uso dentro de la aplicación | Ubicación en el código |
|---|---|---|
| Vector (`int[]`) | Guarda cuántos préstamos se han hecho en cada categoría de libros. Se inicializa en cero, se accede por índice para sumar 1 y se recorre para mostrar el resumen. | `FrmBiblioteca.cs`: variable `prestamosPorCategoria`. Se inicializa en `FrmBiblioteca_Load()`, se actualiza en `Prestar()` y se recorre en `MostrarResumen()` |
| ArrayList (`List<Libro>`) | Guarda el catálogo de libros. Permite agregar, consultar, modificar, eliminar y ordenar. | `FrmBiblioteca.cs`: variable `catalogo`. Se usa en `CrearLibro()`, `BuscarLibro()`, `btnModificar_Click()`, `btnEliminar_Click()`, `btnBuscar_Click()` y los botones de ordenar |
| Lista enlazada simple (hecha a mano) | Guarda los préstamos activos. Cada nodo tiene un préstamo y apunta al siguiente. Al devolver un libro, su nodo se elimina. | `Clases.cs`: clases `Nodo` y `ListaPrestamos` con los métodos `Insertar`, `BuscarPorCodigo`, `BuscarPorUsuario`, `Eliminar` y `Recorrer` |

## Archivos

- `Clases.cs`: Libro, Prestamo, Nodo y ListaPrestamos (la lista enlazada).
- `FrmBiblioteca.cs`: el código del formulario.
- `FrmBiblioteca.Designer.cs`: los botones, cuadros de texto y listas del formulario.
- `Program.cs`: inicia el programa.
